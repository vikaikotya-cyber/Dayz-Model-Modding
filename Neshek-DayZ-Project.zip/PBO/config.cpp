class CfgPatches
{
    class Neshek_AVS36
    {
        units[] = {};
        weapons[] = {"AVS36"};
        magazines[] = {"Mag_AVS_36_10", "Mag_AVS_36_15"};
        requiredVersion = 0.1;
        requiredAddons[] = {"DZ_Data", "DZ_Weapons_Firearms", "DZ_Weapons_Magazines"};
    };
};

class Mode_SemiAuto;
class Mode_FullAuto;
class CfgWeapons
{
    class Rifle;
    class Neshek_AVS36_Base : Rifle
    {
        scope = 0;
        handAnim[] = {"OFP2_ManSkeleton", "\\DZ\\anims\\data\\anim\\sdr\\ik\\weapons\\svd.rtm"};
        lootTag[] = {"Military_east"};
        itemSize[] = {8, 3};
        WeaponLength = 1.23;
        weight = 4300;
        absorbency = 0.1;
        repairableWithKits[] = {5, 1};
        repairCosts[] = {30, 25};
        modelOptics = "-";
        distanceZoomMin = 100;
        distanceZoomMax = 100;
        optics = 1;
        opticsFlare = 0;
        value = 0;
        chamberSize = 1;
        chamberableFrom[] = {"Ammo_762x54"};
        magazines[] = {"Mag_AVS_36_10", "Mag_AVS_36_15"};
        magazineSwitchTime = 0.2;
        barrelArmor = 3000;
        ejectType = 1;
        recoilModifier[] = {1, 4, 1.9};
        swayModifier[] = {1, 1, 1};
        drySound[] = {"\\DZ\\sounds\\weapons\\firearms\\SKS\\SKS_dry", 0.5, 1, 20};
        reloadAction = "ReloadSVD";
        reloadMagazineSound[] = {"\\DZ\\sounds\\weapons\\firearms\\akm\\Akm_reload", 0.8, 1, 20};
        modes[] = {"SemiAuto", "FullAuto"};
        class SemiAuto : Mode_SemiAuto
        {
            soundSetShot[] = {"AK_Shot_SoundSet", "AK_Tail_SoundSet", "AK_InteriorTail_SoundSet"};
            soundSetShotExt[] = {{"AK_silencer_SoundSet", "AK_silencerTail_SoundSet", "AK_silencerInteriorTail_SoundSet"}, {"AK_silencerHomeMade_SoundSet", "AK_silencerHomeMadeTail_SoundSet", "AK_silencerHomeMadeInteriorTail_SoundSet"}};
            begin1[] = {"\\DZ\\sounds\\weapons\\firearms\\akm\\Akm_single_0", 1, 1, 900};
            begin2[] = {"\\DZ\\sounds\\weapons\\firearms\\akm\\Akm_single_1", 1, 1, 900};
            begin3[] = {"\\DZ\\sounds\\weapons\\firearms\\akm\\Akm_single_2", 1, 1, 900};
            soundBegin[] = {"begin1", 0.33333, "begin2", 0.33333, "begin3", 0.33334};
            reloadTime = 0.12;
            recoil = "recoil_svd";
            recoilProne = "recoil_svd_prone";
            dispersion = 0.0015;
            magazineSlot = "magazine";
            beginSilenced_Pro[] = {"\\DZ\\sounds\\weapons\\firearms\\AK101\\akSilenced", 1, 1, 200};
            beginSilenced_HomeMade[] = {"\\DZ\\sounds\\weapons\\firearms\\AK101\\akSilenced", 1, 1, 300};
            soundBeginExt[] = {{"beginSilenced_Pro", 1}, {"beginSilenced_HomeMade", 1}};
        };
        class FullAuto : Mode_FullAuto
        {
            soundSetShot[] = {"AK_Shot_SoundSet", "AK_Tail_SoundSet", "AK_InteriorTail_SoundSet"};
            soundSetShotExt[] = {{"AK_silencer_SoundSet", "AK_silencerTail_SoundSet", "AK_silencerInteriorTail_SoundSet"}, {"AK_silencerHomeMade_SoundSet", "AK_silencerHomeMadeTail_SoundSet", "AK_silencerHomeMadeInteriorTail_SoundSet"}};
            begin1[] = {"\\DZ\\sounds\\weapons\\firearms\\akm\\Akm_single_0", 1, 1, 900};
            begin2[] = {"\\DZ\\sounds\\weapons\\firearms\\akm\\Akm_single_1", 1, 1, 900};
            begin3[] = {"\\DZ\\sounds\\weapons\\firearms\\akm\\Akm_single_2", 1, 1, 900};
            soundBegin[] = {"begin1", 0.33333, "begin2", 0.33333, "begin3", 0.33334};
            reloadTime = 0.1;
            recoil = "recoil_svd";
            recoilProne = "recoil_svd_prone";
            dispersion = 0.0015;
            magazineSlot = "magazine";
            beginSilenced_Pro[] = {"\\DZ\\sounds\\weapons\\firearms\\AK101\\akSilenced", 1, 1, 200};
            beginSilenced_HomeMade[] = {"\\DZ\\sounds\\weapons\\firearms\\AK101\\akSilenced", 1, 1, 300};
            soundBeginExt[] = {{"beginSilenced_Pro", 1}, {"beginSilenced_HomeMade", 1}};
        };
    };
    class AVS36 : Neshek_AVS36_Base
    {
        scope = 2;
        displayName = "AVS-36";
        descriptionShort = "Soviet automatic rifle (1936), 7.62x54R.";
        model = "Neshek\\AVS_36\\AVS_36\\AVS_36.p3d";
        attachments[] = {"weaponButtstockAK", "WeaponHandguardAK", "weaponOpticsAK", "weaponFlashlight", "weaponBipod", "weaponWrap", "weaponBayonetAK", "suppressorImpro", "weaponMuzzleAK"};
        dexterity = 2.75;
    };
};

class CfgMagazines
{
    class Magazine_Base;
    class Mag_AVS_36_10 : Magazine_Base
    {
        scope = 2;
        displayName = "AVS-36 Magazine (10 rnd)";
        descriptionShort = "10-round magazine for the AVS-36. 7.62x54R.";
        model = "Neshek\\AVS_36\\AVS_36\\proxy\\Mag_AVS_36_10.p3d";
        ammo = "Bullet_762x54";
        count = 10;
        initSpeed = 840;
        weight = 250;
        itemSize[] = {2, 2};
        ammoItems[] = {"Ammo_762x54", "Ammo_762x54Tracer"};
        hiddenSelections[] = {"camo"};
        hiddenSelectionsTextures[] = {"Neshek\\AVS_36\\AVS_36\\data\\svt40_diffuse_co.paa"};
        hiddenSelectionsMaterials[] = {"Neshek\\AVS_36\\AVS_36\\data\\svt40_diffuse.rvmat"};
    };
    class Mag_AVS_36_15 : Mag_AVS_36_10
    {
        displayName = "AVS-36 Magazine (15 rnd)";
        model = "Neshek\\AVS_36\\AVS_36\\proxy\\Mag_AVS_36_15.p3d";
        count = 15;
    };
};
