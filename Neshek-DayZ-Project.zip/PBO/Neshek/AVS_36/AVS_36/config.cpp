class CfgPatches
{
    class Mod_AVS36
    {
        units[] = {};
        weapons[] = {"AVS36"};
        magazines[] = {"Mag_AVS_36_10"};                 // FIX #04
        requiredVersion = 0.1;
        requiredAddons[] =
        {
            "DZ_Data",
            "DZ_Weapons_Firearms",
            "DZ_Weapons_Magazines"                       // FIX #11
        };
    };
};

class Mode_Safe;
class Mode_SemiAuto;
class Mode_Burst;
class Mode_FullAuto;

class CfgWeapons
{
    class Rifle;

    // Hidden base class. Keep scope = 0, do not spawn.
    class Mod_AVS36 : Rifle
    {
        scope = 0;
        handAnim[] = {"OFP2_ManSkeleton", "\DZ\anims\data\anim\sdr\ik\weapons\svd.rtm"};
        lootTag[] = {"Military_east"};
        itemSize[] = {8, 3};                             // FIX #13
        WeaponLength = 1.23;                             // FIX #13
        weight = 4300;
        absorbency = 0.1;
        repairableWithKits[] = {5, 1};                   // FIX #10
        repairCosts[] = {30, 25};                        // FIX #10
        modelOptics = "-";
        distanceZoomMin = 100;
        distanceZoomMax = 100;
        optics = 1;
        opticsFlare = 0;
        value = 0;
        chamberSize = 1;
        chamberedRound = "";
        chamberableFrom[] = {"Ammo_762x54"};             // FIX #03
        magazines[] = {"Mag_AVS_36_10"};
        magazineSwitchTime = 0.2;
        barrelArmor = 3000;
        ejectType = 1;
        recoilModifier[] = {1, 4, 1.9};                  // FIX #06
        swayModifier[] = {1, 1, 1};
        drySound[] = {"\DZ\sounds\weapons\firearms\SKS\SKS_dry", 0.5, 1, 20};
        reloadAction = "ReloadSVD";
        reloadMagazineSound[] = {"\DZ\sounds\weapons\firearms\akm\Akm_reload", 0.8, 1, 20};
        modes[] = {"SemiAuto", "FullAuto"};              // FIX #12

        class SemiAuto : Mode_SemiAuto                    // FIX #12
        {
            soundSetShot[] = {"AK_Shot_SoundSet", "AK_Tail_SoundSet", "AK_InteriorTail_SoundSet"};
            soundSetShotExt[] = {{"AK_silencer_SoundSet", "AK_silencerTail_SoundSet", "AK_silencerInteriorTail_SoundSet"}, {"AK_silencerHomeMade_SoundSet", "AK_silencerHomeMadeTail_SoundSet", "AK_silencerInteriorHomeMadeTail_SoundSet"}};
            begin1[] = {"\DZ\sounds\weapons\firearms\akm\Akm_single_0", 1, 1, 900};
            begin2[] = {"\DZ\sounds\weapons\firearms\akm\Akm_single_1", 1, 1, 900};
            begin3[] = {"\DZ\sounds\weapons\firearms\akm\Akm_single_2", 1, 1, 900};
            soundBegin[] = {"begin1", 0.33333, "begin2", 0.33333, "begin3", 0.33334}; // FIX #07
            reloadTime = 0.12;
            recoil = "recoil_svd";
            recoilProne = "recoil_svd_prone";
            dispersion = 0.0015;
            magazineSlot = "magazine";
            beginSilenced_Pro[] = {"\DZ\sounds\weapons\firearms\AK101\akSilenced", 1, 1, 200};
            beginSilenced_HomeMade[] = {"\DZ\sounds\weapons\firearms\AK101\akSilenced", 1, 1, 300};
            soundBeginExt[] = {{"beginSilenced_Pro", 1}, {"beginSilenced_HomeMade", 1}};
        };

        class FullAuto : Mode_FullAuto
        {
            soundSetShot[] = {"AK_Shot_SoundSet", "AK_Tail_SoundSet", "AK_InteriorTail_SoundSet"};
            soundSetShotExt[] = {{"AK_silencer_SoundSet", "AK_silencerTail_SoundSet", "AK_silencerInteriorTail_SoundSet"}, {"AK_silencerHomeMade_SoundSet", "AK_silencerHomeMadeTail_SoundSet", "AK_silencerInteriorHomeMadeTail_SoundSet"}};
            begin1[] = {"\DZ\sounds\weapons\firearms\akm\Akm_single_0", 1, 1, 900};
            begin2[] = {"\DZ\sounds\weapons\firearms\akm\Akm_single_1", 1, 1, 900};
            begin3[] = {"\DZ\sounds\weapons\firearms\akm\Akm_single_2", 1, 1, 900};
            soundBegin[] = {"begin1", 0.33333, "begin2", 0.33333, "begin3", 0.33334}; // FIX #07
            reloadTime = 0.1;
            recoil = "recoil_svd";
            recoilProne = "recoil_svd_prone";
            dispersion = 0.0015;
            magazineSlot = "magazine";
            beginSilenced_Pro[] = {"\DZ\sounds\weapons\firearms\AK101\akSilenced", 1, 1, 200};
            beginSilenced_HomeMade[] = {"\DZ\sounds\weapons\firearms\AK101\akSilenced", 1, 1, 300};
            soundBeginExt[] = {{"beginSilenced_Pro", 1}, {"beginSilenced_HomeMade", 1}};
        };
    };

    // Public weapon class: sibling to the base, direct child of CfgWeapons.
    class AVS36 : Mod_AVS36                          // FIX #01 + #02
    {
        scope = 2;
        displayName = "AVS-36";                      // FIX #08
        descriptionShort = "Soviet automatic rifle (1936), 7.62x54R."; // FIX #08
        model = "Neshek\AVS_36\AVS_36\AVS_36.p3d";
        attachments[] = {"weaponButtstockAK", "WeaponHandguardAK", "weaponOpticsAK", "weaponFlashlight", "weaponBipod", "weaponWrap", "weaponBayonetAK", "suppressorImpro", "weaponMuzzleAK"};
        baseAttachments[] = {"Att_Buttstock_AK_Wood", "Att_Handguard_AK_Wood"};
        randomAttachments[] = {{"Att_Buttstock_AK74", "Att_Buttstock_AK_Folding", "Att_Buttstock_AK_Plastic", "Att_Buttstock_AKS74U", "Att_Buttstock_AK_Wood", "Att_Buttstock_AK_Wood", "Att_Buttstock_AK_Wood", "Att_Buttstock_AK_Wood", "Att_Buttstock_AK_Wood", "Att_Buttstock_AK_Wood", "Att_Buttstock_AK_Wood", "Att_Buttstock_AK_Wood"}, {"Att_Handguard_AK74", "Att_Handguard_AK_Rail", "Att_Handguard_AK_Plastic", "Att_Handguard_AK_Wood", "Att_Handguard_AK_Wood", "Att_Handguard_AK_Wood", "Att_Handguard_AK_Wood", "Att_Handguard_AK_Wood", "Att_Handguard_AK_Wood"}, {"Att_Optic_Kashtan", "Att_Optic_PSO11", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", ""}, {"Att_Suppressor_AK", "", "", "", "", "", "", "", "", ""}, {"Mag_AVS_36_10", "", "", "", "", "", "", "", "", ""}}; // FIX #05
        dexterity = 2.75;

        // FIX #09: old Arma-style "class Damage" removed.
        // Materials must match this model, not AKM rvmats.
        // Check hiddenSelectionsMaterials[] / DamageSystem against AVS_36 assets.
    };
};

class CfgMagazines
{
    class Magazine_Base;

    class Mag_AVS_36_10 : Magazine_Base               // FIX #04
    {
        scope = 2;
        displayName = "AVS-36 Mag (10)";
        descriptionShort = "10-round magazine for the AVS-36. 7.62x54R.";
        model = "Neshek\AVS_36\AVS_36\proxy\mag_AVS_36_10.p3d";           // match your asset
        picture = "AVS_36\data\mag_AVS_36_10.paa";    // match your asset
        ammo = "Bullet_762x54";
        count = 10;
        initSpeed = 840;
        weight = 250;
        itemSize[] = {2, 2};
        color = "Green";
    };
};