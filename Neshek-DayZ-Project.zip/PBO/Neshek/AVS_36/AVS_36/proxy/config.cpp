class CfgMagazines {
	class DefaultMagazine;	// External class reference
	
	class MagazineBase : DefaultMagazine {
		scope = 0;
		lootCategory = "Magazines";
		storageCategory = 1;
		inventorySlot[] = {"magazine", "magazine2", "magazine3"};
		handheld = 1; // Исправлено: заменена строка "true" на integer/bool
		armAction = "Disarm";
		rotateAlways = 1;
		quantityBar = 0;
		itemSize[] = {1, 2};
		absorbency = 0.1;
		value = 1;
		modelSpecial = "";
		useAction = 0;
		useActionTitle = "";
		reloadAction = "";
		count = 30;
		ammo = "";
		ammoItems[] = {};
		varQuantityInit = 1;
		varQuantityMin = 0;
		varQuantityMax = 1;
		type = 256;
		selectionFireAnim = "zasleh";
		nameSound = "magazine";
		soundUse = "craft_rounds";
		tooltip = "_text = _this call fnc_generateTooltip;_text";
		synchronizedVariables[] = {"temperature", 0.2};
		
		class EventHandlers {
			Killed = "[1, (_this select 0)] spawn event_ammo";
		};
		
		class DamageSystem {
			class GlobalHealth {
				class Health {
					hitpoints = 100;
				};
			};
		};
		
		class Melee {
			range = 1.0;
			swingTime = 0.5;
			action = "MeleeAttack2";
			ammo = "MeleeFist";
			useCursor = 1;
		};
	};
	
	class Mag_AVS_36_10 : MagazineBase {
		scope = 2;
		displayName = "Mag_AVS_36_10";
		descriptionShort = "7.62×54mmR";
		model = "\Neshek\AVS_36\AVS_36\proxy\Mag_AVS_36_10.p3d";
		handAnim[] = {"OFP2_ManSkeleton", "\DZ\anims\data\anim\sdr\ik\weapons\magazines\magazine_pmag.rtm"};
		lootTag[] = {"Military_east"};
		weight = 120;
		itemSize[] = {1, 1};
		count = 10;
		ammo = "B_762x54_Ball";
		// Исправлено: указаны стандартные классы патронов DayZ (измените обратно, если у вас свои кастомные классы)
		ammoItems[] = {"Ammo_762x54", "Ammo_762x54Tracer"}; 
		tracersEvery = 0;
		hiddenSelections[] = {"camo"};
		// Исправлено: добавлен ведущий обратный слэш '\' в путях ниже
		hiddenSelectionsTextures[] = {"\Neshek\AVS_36\AVS_36\data\svt40_diffuse_co.paa"};
		hiddenSelectionsMaterials[] = {"\Neshek\AVS_36\AVS_36\data\svt40_diffuse.rvmat"};
	};
};